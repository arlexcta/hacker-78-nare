HACKER 78 NARE — PROYEK ANDROID UNTUK BUILD CLOUD
Tema: hitam + neon hijau

PENTING
- ZIP ini adalah kode sumber, bukan APK yang sudah jadi.
- Workflow GitHub Actions disertakan untuk membuat APK debug di cloud tanpa laptop.
- Login dan database online TIDAK akan berfungsi sampai Firebase milik Anda dikonfigurasi.

CARA BUILD APK DARI HP ANDROID
1. Ekstrak ZIP ini menggunakan aplikasi pengelola file.
2. Buka https://github.com/ di browser HP dan masuk/buat akun.
3. Buat repository baru bernama hacker-78-nare. Pilih Public atau Private, lalu Create repository.
4. Di repository, gunakan Add file > Upload files. Unggah isi folder hacker78nare (termasuk folder .github). Jika pengelola file tidak menampilkan folder tersembunyi .github, aktifkan tampilan file tersembunyi.
5. Commit perubahan ke branch main.
6. Buka tab Actions pada repository dan pilih workflow “Build HACKER 78 NARE APK”. Jika diminta, aktifkan Actions. Tekan Run workflow.
7. Tunggu sampai workflow selesai dengan tanda centang hijau.
8. Buka hasil workflow run, cari bagian Artifacts, lalu unduh “HACKER-78-NARE-APK”.
9. Ekstrak ZIP artifact yang diunduh; di dalamnya ada app-debug.apk. Ketuk APK untuk memasang. Android mungkin meminta izin “Install unknown apps” untuk browser atau aplikasi File Manager yang digunakan.

FIREBASE UNTUK LOGIN ONLINE
1. Buka https://console.firebase.google.com/ dan buat proyek.
2. Tambahkan aplikasi Web di Project settings > Your apps.
3. Salin konfigurasi Firebase lalu buka www/index.html. Ganti nilai ISI_API_KEY, ISI_PROJECT_ID, dan ISI_APP_ID pada firebaseConfig.
4. Aktifkan Authentication > Sign-in method > Email/Password.
5. Buat Cloud Firestore Database.
6. Aturan Firestore dasar yang disarankan:

rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}

7. Unggah perubahan www/index.html ke GitHub lalu jalankan workflow lagi.

Catatan: APK debug untuk uji coba. Jangan gunakan database dengan aturan publik. Simpan kunci penandatanganan rilis secara aman bila nanti ingin menerbitkan aplikasi secara resmi.
